package com.learncamel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearncamelSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearncamelSpringBootApplication.class, args);
	}
}
